using UnityEngine;

public class GestorJuego : MonoBehaviour
{
    public Transform pelota;
    public Vector3 posicionInicial = new Vector3(0, 0.5f, -2);
    private Rigidbody rbPelota;
    private int goles = 0;

    void Start()
    {
        rbPelota = pelota.GetComponent<Rigidbody>();
    }

    void Update()
    {
        if (pelota.position.z > 15 || pelota.position.z < -15 || pelota.position.x > 15 || pelota.position.x < -15)
        {
            pelota.position = posicionInicial;
            rbPelota.linearVelocity = Vector3.zero;
            rbPelota.angularVelocity = Vector3.zero;
        }
    }

    public void AnotarGol()
    {
        goles++;
        pelota.position = posicionInicial;
        rbPelota.linearVelocity = Vector3.zero;
        rbPelota.angularVelocity = Vector3.zero;
    }

    public int ObtenerGoles()
    {
        return goles;
    }
}