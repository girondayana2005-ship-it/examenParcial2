using UnityEngine;
using TMPro;
using UnityEngine.InputSystem;
using UnityEngine.SceneManagement;

public class Temporizador : MonoBehaviour
{
    public float tiempoRestante = 30f;
    public TextMeshProUGUI textoUI;
    public GestorJuego gestor;
    private bool juegoTerminado = false;

    void Update()
    {
        if (juegoTerminado)
        {
            if (Keyboard.current != null && Keyboard.current.rKey.wasPressedThisFrame)
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }
            return;
        }

        if (tiempoRestante > 0)
        {
            tiempoRestante -= Time.deltaTime;
            textoUI.text = "Goles: " + gestor.ObtenerGoles() + " | Tiempo: " + Mathf.Ceil(tiempoRestante).ToString();
        }
        else
        {
            tiempoRestante = 0;
            juegoTerminado = true;
            textoUI.text = "Fin del juego\nGoles: " + gestor.ObtenerGoles() + "\nPresiona R para reiniciar";
        }
    }
}