using UnityEngine;

public class TriggerGol : MonoBehaviour
{
    public GestorJuego gestor;
    private bool puedeAnotar = true;

    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Pelota") && puedeAnotar)
        {
            puedeAnotar = false;
            gestor.AnotarGol();
            Invoke("ReactivarTrigger", 1.5f);
        }
    }

    void ReactivarTrigger()
    {
        puedeAnotar = true;
    }
}