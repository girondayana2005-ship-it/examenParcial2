using UnityEngine;

public class RedFisica : MonoBehaviour
{
    private Vector3 escalaOriginal;
    public float fuerzaHundimiento = 0.5f;

    void Start()
    {
        escalaOriginal = transform.localScale;
    }

    void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Pelota"))
        {
            transform.localScale = new Vector3(escalaOriginal.x, escalaOriginal.y, escalaOriginal.z + fuerzaHundimiento);
            Invoke("RestaurarRed", 0.2f);
        }
    }

    void RestaurarRed()
    {
        transform.localScale = escalaOriginal;
    }
}